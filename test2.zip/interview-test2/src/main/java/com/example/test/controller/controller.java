package com.example.test.controller;

import com.example.test.dto.StudentDto;
import com.example.test.service.xmlservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.xml.transform.TransformerConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

@RestController
@RequestMapping("/xml")
public class controller {
    @Autowired
     private xmlservice service;

    @PostMapping(value="/generate")
    ResponseEntity<String> generateXml() throws TransformerConfigurationException, IOException {
        return ResponseEntity.ok(service.generateXml());
    }



}
