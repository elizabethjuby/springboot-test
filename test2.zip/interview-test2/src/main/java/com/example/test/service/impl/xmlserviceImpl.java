package com.example.test.service.impl;

import com.example.test.client.TestClient;
import com.example.test.dto.StudentDto;
import com.example.test.service.xmlservice;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Component
public class xmlserviceImpl implements xmlservice {

    @Autowired
    TestClient client;

    @Value("${xml.file-path}")
    private String filePath;

    @Override
    public String generateXml() throws TransformerConfigurationException, IOException {

        XStream xstream = new XStream(new StaxDriver());
        xstream.autodetectAnnotations(true);
        List<StudentDto> dtos=client.getStudentDtos().getBody();
        String xmlData=xstream.toXML(dtos);
        xmlData = prettyPrintByTransformer(xmlData, 1, false);
        generateFile(xmlData);
        return xmlData;
    }

    private void generateFile(String xmlData) throws IOException {
        Path path
                = Paths.get(filePath);
        byte[] arr = xmlData.getBytes();
        Files.write(path, arr);
    }


    public static String prettyPrintByTransformer(String xmlString, int indent,
                                                  boolean ignoreDeclaration) {
        try {
            InputSource src = new InputSource(new StringReader(xmlString));
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(src);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setAttribute("indent-number", indent);
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
                    ignoreDeclaration ? "yes" : "no");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            Writer out = new StringWriter();
            transformer.transform(new DOMSource(document), new StreamResult(out));
            return out.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error occurs when pretty-printing xml:\n" + xmlString, e);
        }
    }
}
