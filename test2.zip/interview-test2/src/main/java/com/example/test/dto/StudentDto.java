package com.example.test.dto;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XStreamAlias("Student")
public class StudentDto  {
    @XStreamAlias("Id")
    private Long id;
    @XStreamAlias("Student_Name")
    private String stdName;
    @XStreamAlias("Department")
    private String dept;

}
