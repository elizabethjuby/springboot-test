package com.example.test.service;

import com.example.test.dto.StudentDto;

import javax.xml.transform.TransformerConfigurationException;
import java.io.IOException;
import java.util.List;

public interface xmlservice {

   String generateXml() throws TransformerConfigurationException, IOException;


}
