package com.example.test.controller;

import com.example.test.dto.StudentDto;
import com.example.test.service.testservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/test")
public class controller {
    @Autowired
     private testservice service;

    @PostMapping
    ResponseEntity<List<StudentDto>> saveStudents(@RequestBody List<StudentDto> StudentDtos)
    {
        return ResponseEntity.ok(service.save(StudentDtos));
    }

    @GetMapping
    ResponseEntity<List<StudentDto>> findAll()
    {
        return ResponseEntity.ok(service.findAll());
    }

}
