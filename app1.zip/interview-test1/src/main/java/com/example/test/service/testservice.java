package com.example.test.service;

import com.example.test.dto.StudentDto;

import java.util.List;

public interface testservice {

    List<StudentDto> save(List<StudentDto> studentDto);

    List<StudentDto> findAll();
}
