package com.example.test.service.impl;

import com.example.test.domain.Student;
import com.example.test.dto.StudentDto;
import com.example.test.mapper.StudentMapper;
import com.example.test.repository.StudentRepository;
import com.example.test.service.testservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class serviceImpl implements testservice {
    @Autowired
    private StudentMapper studentmapper;

    @Autowired
    private StudentRepository studentRepository;


    @Override
    public List<StudentDto> save(List<StudentDto> studentDto) {
        List<Student> Students =studentmapper.toDomainList(studentDto);
        return studentmapper.toDtoList(studentRepository.saveAll(Students));
    }

    @Override
    public List<StudentDto> findAll() {
        return studentmapper.toDtoList(studentRepository.findAll());
    }
}
